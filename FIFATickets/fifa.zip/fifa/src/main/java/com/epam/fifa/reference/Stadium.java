package com.epam.fifa.reference;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

import com.epam.fifa.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Stadium {
	private int id;
	private HashMap<String, Zone> zones;
	void initializeZones() {
		//long time = System.currentTimeMillis();
		int seats = 5;
		for (int i = 1; i <= 4; i++) {
			HashMap<String, Block> blocks = new HashMap<String, Block>();
			for(int j = 1; j <= 4; j++) {
				Queue<User> userQ = new LinkedList<>();
				Block block = new Block(i, userQ, seats);
				blocks.put("B" + j, block);
			}
			Zone zone = new Zone(i, blocks);
			zones.put("Z" + i, zone);
		}
	}
}
