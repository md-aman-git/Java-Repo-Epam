package com.epam.fifa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifaApplicationTests {

	@Test
	void contextLoads() {
	}

}
