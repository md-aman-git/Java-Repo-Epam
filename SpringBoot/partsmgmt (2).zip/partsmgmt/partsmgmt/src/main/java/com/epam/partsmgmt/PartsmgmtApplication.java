package com.epam.partsmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartsmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartsmgmtApplication.class, args);
	}

}
