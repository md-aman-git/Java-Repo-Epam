package com.epam.partsmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartsmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
