package com.epam.orders.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.orders.entity.Order;
import com.epam.orders.repo.OrderRepo;
import com.epam.orders.service.OrderService;
import com.epam.orders.vo.OrderVO;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	OrderRepo orderRepo;
	@Override
	public void updateOrder(OrderVO orderVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOrderById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrder(OrderVO orderVO) {
		// TODO Auto-generated method stub
		Order order = new Order();
		order.setOrder_id(orderVO.getOrder_id());
		order.setQuantity(orderVO.getQuantity());
		order.setTotal_price(orderVO.getTotal_price());
		orderRepo.save(order);
	}

	@Override
	public OrderVO findById(int id) {
		// TODO Auto-generated method stub
		Order order = orderRepo.findById(id);
		OrderVO orderVO = new OrderVO();
		orderVO.setOrder_id(order.getOrder_id());
		orderVO.setQuantity(order.getQuantity());
		orderVO.setTotal_price(order.getTotal_price());
		orderVO.setId(order.getId());
		return orderVO;
	}

	@Override
	public List<OrderVO> findAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

}
