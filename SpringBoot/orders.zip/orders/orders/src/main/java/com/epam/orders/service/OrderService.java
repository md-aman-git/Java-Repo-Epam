package com.epam.orders.service;

import java.util.List;

import com.epam.orders.vo.OrderVO;

public interface OrderService {

	void updateOrder(OrderVO orderVO);

	void deleteOrderById(int id);

	void saveOrder(OrderVO orderVO);

	OrderVO findById(int id);

	List<OrderVO> findAllOrders();

}
