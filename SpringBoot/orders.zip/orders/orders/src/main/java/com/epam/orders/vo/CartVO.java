package com.epam.orders.vo;

import com.epam.orders.entity.ProductVO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartVO {
	private int id;
	private int order_id_int;
	private ProductVO productVO;
	private int price;
	private int quantity;
}
