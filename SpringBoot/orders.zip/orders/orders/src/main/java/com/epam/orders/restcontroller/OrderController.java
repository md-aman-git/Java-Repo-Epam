package com.epam.orders.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.epam.orders.entity.ProductVO;
import com.epam.orders.service.OrderService;
import com.epam.orders.vo.OrderVO;

@RestController
public class OrderController {
	@Autowired
	OrderService orderService;
	@GetMapping("/orders")
	public ResponseEntity<List<OrderVO>> getOrders() {
		System.out.println("Hello products");
		List<OrderVO> ordersVO = orderService.findAllOrders();
		return new ResponseEntity<>(ordersVO, HttpStatus.OK);
	}
	@GetMapping("/orders/{id}")
	public ResponseEntity<OrderVO> getOrders(@PathVariable int id) {
		System.out.println("Hello product with id : " + id);
		OrderVO orderVO = orderService.findById(id);
		return new ResponseEntity<>(orderVO, HttpStatus.OK);
	}
	@PostMapping("/orders")
	public ResponseEntity<String> saveOrder(@RequestBody OrderVO orderVO) {
		orderService.saveOrder(orderVO);
		return new ResponseEntity<>("Saved Order!", HttpStatus.CREATED);
	}
	@DeleteMapping("/orders/{id}")
	public ResponseEntity<String> deleteOrder(@PathVariable int id) {
		orderService.deleteOrderById(id);
		System.out.println("Delete ID : " + id);
		return new ResponseEntity<>("Deleted : " + id, HttpStatus.OK);
	}
	@PutMapping("/orders")
	public ResponseEntity<String> updateOrder(@RequestBody OrderVO orderVO) {
		orderService.updateOrder(orderVO);
		return new ResponseEntity<>("Updated : " + orderVO.getId(), HttpStatus.OK);
	}
	@GetMapping("/findProduct/{id}") 
	public String findProduct(@PathVariable int id) {
		RestTemplate restTemplate = new RestTemplate();
		String REST_SERVICE_URI = "http://localhost:8080/products/" + id;
		ProductVO productVO = restTemplate.getForObject(REST_SERVICE_URI, ProductVO.class);
//		System.out.println("GenderVO : " + genderVO);
		return productVO.toString();
	}
}
